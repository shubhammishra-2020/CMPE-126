#include <iostream>
#include "mainex1.cpp"
using namespace std;

int main() {
	mainex1();
}

