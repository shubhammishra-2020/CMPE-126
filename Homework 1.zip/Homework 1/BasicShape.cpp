#include <iostream>
using namespace std;
#include "BasicShape.h"

double BasicShape::getArea() {
	return area;
}
